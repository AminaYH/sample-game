/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.thevpc.gaming.atom.examples.kombla;

import net.thevpc.gaming.atom.Atom;

import net.thevpc.gaming.atom.examples.kombla.main.client.engine.MainClientEngine;
import net.thevpc.gaming.atom.examples.kombla.main.client.presentation.MainClientScene;
import net.thevpc.gaming.atom.examples.kombla.main.local.presentation.MainLocalScene;
import net.thevpc.gaming.atom.examples.kombla.main.server.engine.MainServerEngine;
import net.thevpc.gaming.atom.examples.kombla.main.server.presentation.MainServerScene;
import net.thevpc.gaming.atom.presentation.Game;

/**
 * @author Taha Ben Salah (taha.bensalah@gmail.com)
 */

public class KomblaGame {

    public static void main(String[] args) {
//        Game game = Atom.createGame();
//      MainServerEngine serverEngine = new MainServerEngine();
//        game.addScene(new MainServerScene(), serverEngine);
//        MainClientEngine clientEngine = new MainClientEngine();
//
//        game.addScene(new MainClientScene(), clientEngine);
//

        Atom.startGame();

    }
}
