package net.thevpc.gaming.atom.examples.kombla.welcome;

import net.thevpc.gaming.atom.annotations.AtomSceneEngine;

/**
 * Created by vpc on 10/7/16.
 */
@AtomSceneEngine(id = "welcome",welcome = true)
public class WelcomeEngine {
}
