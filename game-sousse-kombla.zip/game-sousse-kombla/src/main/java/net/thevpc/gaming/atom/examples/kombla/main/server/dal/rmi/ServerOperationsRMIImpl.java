/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.thevpc.gaming.atom.examples.kombla.main.server.dal.rmi;

import net.thevpc.gaming.atom.examples.kombla.main.client.dal.MainClientDAOListener;
import net.thevpc.gaming.atom.examples.kombla.main.client.dal.rmi.clientOperationRMI;
import net.thevpc.gaming.atom.examples.kombla.main.server.dal.MainServerDAOListener;
import net.thevpc.gaming.atom.examples.kombla.main.shared.model.DynamicGameModel;
import net.thevpc.gaming.atom.model.Player;
import net.thevpc.gaming.atom.model.Sprite;


import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 * @author Taha Ben Salah (taha.bensalah@gmail.com)
 */
public class ServerOperationsRMIImpl extends UnicastRemoteObject implements ServerOperationsRMI {

    private MainServerDAOListener listener;
    private clientOperationRMI client;
    private ServerOperationsRMI server;
    private DynamicGameModel dynamicGameModel;

    public ServerOperationsRMIImpl(MainServerDAOListener listener) throws RemoteException {
        super();
        if (listener == null) {
            throw new IllegalArgumentException("Listener cannot be null");
        }
        this.listener = listener;
    }

    public clientOperationRMI getClient() {
            return this.client;
    }

    @Override
    public void setClient(clientOperationRMI client) throws RemoteException {
        this.client=client;
        listener.onReceivePlayerJoined("Boss1");
    }

    @Override
    public void keyLeft() throws RemoteException {
        server.keyLeft();
    }

    @Override
    public void keyRight() throws RemoteException {
        server.keyRight();
    }

    @Override
    public void keySpace() throws RemoteException {
server.keySpace();
    }






}
