/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.thevpc.gaming.atom.examples.kombla.main.local.engine;

import net.thevpc.gaming.atom.annotations.AtomSceneEngine;
import net.thevpc.gaming.atom.examples.kombla.main.shared.engine.BaseMainEngine;


/**
 * @author Taha Ben Salah (taha.bensalah@gmail.com)
 */
@AtomSceneEngine(id = "mainLocal", columns = 12, rows = 12)
public class MainLocalEngine extends BaseMainEngine {
    public MainLocalEngine() {
    }
}
